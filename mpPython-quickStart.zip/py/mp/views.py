from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse


def index(request): # rest
	from melipayamak import Api
	username = 'username'
	password = 'password'
	api = Api(username,password)
	sms = api.sms()
	to = '09123456789'
	_from = '5000...'
	text = 'تست وب سرویس ملی پیامک'
	response = sms.send(to,_from,text)
	return HttpResponse(response)


def soap(request): # soap
	from melipayamak import Api
	username = 'username'
	password = 'password'
	api = Api(username,password)
	sms = api.sms('soap')
	to = '09123456789'
	_from = '5000...'
	text = 'تست وب سرویس ملی پیامک'
	response = sms.send(to,_from,text)
	return HttpResponse(response)