from django.apps import AppConfig


class MpConfig(AppConfig):
    name = 'mp'
