from .rest import Rest
from .soap import Soap